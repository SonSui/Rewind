// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "RewindEnemyBaseCharacter.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "NiagaraSystem.h"
#include "EnemyGruxCharacter.generated.h"

/**
 * 
 */
UCLASS()
class REWIND_API AEnemyGruxCharacter : public ARewindEnemyBaseCharacter
{
	GENERATED_BODY()
public:
	AEnemyGruxCharacter();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;

	// ========== ��� ==========
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|State")
	EEnemyState CurrentState = EEnemyState::Idle;

	

	// ========== �X�e�[�^�X ==========

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stats")
	float MoveSpeed = 300.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stats")
	float MaxMoveSpeed = 600.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stats")
	float RotationSpeed = 360.0f;

	// ========== ���� ==========
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Sight")
	float SightAngle = 60.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Sight")
	float SightRadius = 800.0f;

	// ========== �U�� ==========
	

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Combat")
	float AttackRange = 250.0f;

	UPROPERTY(EditDefaultsOnly, Category = "VFX")
	UNiagaraSystem* HitSparkEffect;

	// ========== ��e�E�d�� ==========
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stun")
	float StunTime = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stun")
	float DefaultStunTime = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stun")
	int32 Toughness = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stun")
	int32 DefaultToughness = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stun")
	bool bStunable = false;


	// ========== �p�g���[�� ==========
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Patrol")
	FVector SpawnPoint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Patrol")
	float PatrolRadius = 600.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Patrol")
	float PatrolInterval = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Patrol")
	float DefaultPatrolInterval = 5.0f;

	

	// ========== �A�j���[�V���� ==========
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Animation")
	UAnimMontage* AttackPreMontage;

	

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Animation")
	UAnimMontage* AttackMontage2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Animation")
	UAnimMontage* StunMontage;

	

	// ========== �s���֐��iBTTask�EState�Ǘ��p�j ==========
	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	bool EnterIdle(bool bShouldRestartBT = false);

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	bool EnterPatrol();

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	bool EnterChase(AActor* PlayerActor);

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	bool EnterAttack();
	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	void StartAttack1();
	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	void StartAttack2();

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	void EnterStun();

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	void EnterDeath();

	//UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	//void EnterRewind();
	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	bool MoveToLocation(const FVector& Location);

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	void FaceTarget(const FVector& TargetLocation);

	UFUNCTION(BlueprintCallable, Category = "Grux|Action")
	void TryTurnToPlayer();

	// ========== �⏕�֐� ==========
	UFUNCTION(BlueprintCallable, Category = "Grux|Helper")
	bool CanAttack() const;

	UFUNCTION(BlueprintCallable, Category = "Grux|Helper")
	bool IsInAttackRange(const FVector& PlayerLocation) const;

	UFUNCTION(BlueprintCallable, Category = "Grux|Helper")
	bool IsPlayerVisible() const;

	UFUNCTION(BlueprintCallable, Category = "Grux|Helper")
	void ResetToughness();

	UFUNCTION(BlueprintCallable, Category = "Grux|Helper")
	void ResetStunTime();
	// �s�����W�b�N�̈ꎞ��~ 
	UFUNCTION(BlueprintCallable, Category = "Grux|BT Control")
	void StopBTLogic(const FString& Reason);

	// �s�����W�b�N�̍ĊJ 
	UFUNCTION(BlueprintCallable, Category = "Grux|BT Control")
	void RestartBTLogic();
	UFUNCTION(BlueprintCallable, Category = "Grux|BT Control")
	FVector GetSpawnPoint() const { return SpawnPoint; }

	

	// ========== �s���t���O�iBTTask�EState�Ǘ��p�j ==========
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Behavior")
	bool bCanPatrol = true;  // �p�g���[���\���ǂ���

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Behavior")
	bool bOverPatrolRange = false;  // �p�g���[���͈͊O���ǂ���

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Behavior")
	FVector MoveTargetLocation;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Behavior")
	AActor* TargetActor;  // �U���Ώ�
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Behavior")
	bool bPlayerDetected = false;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Grux|Behavior")
	bool bPlayerInAttackRange = false;
	
	// ========== BehaviorTree ==========
	UPROPERTY(EditDefaultsOnly, Category = "AI")
	UBehaviorTree* BehaviorTreeAsset;
};
