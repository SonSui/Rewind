// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_ChasePlayer.h"
#include "EnemyGruxCharacter.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"

UBTTask_ChasePlayer::UBTTask_ChasePlayer()
{
	NodeName = TEXT("Chase Player");
}

EBTNodeResult::Type UBTTask_ChasePlayer::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AEnemyGruxCharacter* Grux = Cast<AEnemyGruxCharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (!Grux) return EBTNodeResult::Failed;

	UBlackboardComponent* BB = OwnerComp.GetBlackboardComponent();
	if (!BB) return EBTNodeResult::Failed;

	AActor* Player = Cast<AActor>(OwnerComp.GetBlackboardComponent()->GetValueAsObject(TEXT("TargetActor")));
	if (!Player) return EBTNodeResult::Failed;

	Grux->EnterChase(Player);
	BB->SetValueAsVector(TEXT("TargetLocation"), Grux->MoveTargetLocation);

	UE_LOG(LogTemp, Warning, TEXT("UBTTask_ChasePlayer "));

	return EBTNodeResult::Succeeded;
}