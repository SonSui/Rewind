// Fill out your copyright notice in the Description page of Project Settings.

#include "RewindPlayerCharacter.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/PlayerController.h"
#include "RewindAnimInstance.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/CharacterMovementComponent.h"

ARewindPlayerCharacter::ARewindPlayerCharacter()
{
	GetMesh()->SetRelativeRotation(FRotator(0.0f, -90.0f, 0.0f));
	GetMesh()->SetRelativeLocation(FVector(0.0f, 0.0f, -90.0f));

	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	PrimaryActorTick.bCanEverTick = true;

	// �J�����A�[���̍쐬
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = 300.0f; // �J��������
	CameraBoom->bUsePawnControlRotation = true; // �J�������R���g���[���[�ɒǏ]

	// �t�H���[�J�����̍쐬
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	FollowCamera->bUsePawnControlRotation = false; // �J�����͓Ǝ��ɉ�]���Ȃ�

	PrimaryActorTick.bCanEverTick = true;

	CurrentHealth = MaxHealth; // �����̗͐ݒ�


	
}

void ARewindPlayerCharacter::BeginPlay()
{
	Super::BeginPlay();

	// ���̓}�b�s���O��o�^
	if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
		{
			if (DefaultMappingContext)
			{
				Subsystem->AddMappingContext(DefaultMappingContext, 0);
			}
		}
	}
}

void ARewindPlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	if (UEnhancedInputComponent* EnhancedInput = CastChecked<UEnhancedInputComponent>(PlayerInputComponent))
	{
		if (MoveAction)
		{
			EnhancedInput->BindAction(MoveAction, ETriggerEvent::Triggered, this, &ARewindPlayerCharacter::Move);
		}
		if (LookAction)
		{
			EnhancedInput->BindAction(LookAction, ETriggerEvent::Triggered, this, &ARewindPlayerCharacter::Look);
		}
		if (AttackAction)
		{
			EnhancedInput->BindAction(AttackAction, ETriggerEvent::Started, this, &ARewindPlayerCharacter::Attack);
		}
		if (DefendAction)
		{
			EnhancedInput->BindAction(DefendAction, ETriggerEvent::Started, this, &ARewindPlayerCharacter::StartDefend);
			EnhancedInput->BindAction(DefendAction, ETriggerEvent::Completed, this, &ARewindPlayerCharacter::EndDefend);
		}
		//if (RewindAction)
		//{
			//EnhancedInput->BindAction(RewindAction, ETriggerEvent::Triggered, this, &ARewindPlayerCharacter::TriggerHitRewind);
		//}
	}
}

void ARewindPlayerCharacter::Move(const FInputActionValue& Value)
{
	if (bIsAttacking||bIsDefending) return; // �U�����͈ړ��֎~
	const FVector2D MovementVector = Value.Get<FVector2D>();
	CurrentInputVector = MovementVector;

	const FRotator ControlRotation = Controller ? Controller->GetControlRotation() : FRotator::ZeroRotator;
	const FRotator YawRotation(0, ControlRotation.Yaw, 0);

	// ���E�����֕ϊ�
	const FVector ForwardDir = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
	const FVector RightDir = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);

	// �ړ�
	AddMovementInput(ForwardDir, MovementVector.Y);
	AddMovementInput(RightDir, MovementVector.X);

	// �J�����ɂ��킹�ĉ�]
	if (!MovementVector.IsNearlyZero())
	{
		const FVector WorldInput = ForwardDir * MovementVector.Y + RightDir * MovementVector.X;
		const FRotator TargetRotation = WorldInput.Rotation();
		
		const FRotator NewRotation = FMath::RInterpTo(GetActorRotation(), TargetRotation, GetWorld()->GetDeltaSeconds(), 10.0f);
		SetActorRotation(NewRotation);
	}

	const FVector InputDirectionWorld = ForwardDir * MovementVector.Y + RightDir * MovementVector.X;

	// �L�����N�^�[�̃��[�J�����W�n�ɕϊ�
	const FVector InputInLocal = GetActorTransform().InverseTransformVector(InputDirectionWorld);

	// �A�j���[�V�����pInputVector�ɐݒ�
	if (URewindAnimInstance* AnimInstance = Cast<URewindAnimInstance>(GetMesh()->GetAnimInstance()))
	{
		AnimInstance->InputVector = FVector2D(InputInLocal.Y, InputInLocal.X);
		
	}
}

void ARewindPlayerCharacter::Look(const FInputActionValue& Value)
{
	const FVector2D LookAxisVector = Value.Get<FVector2D>();

	if (Controller)
	{
		AddControllerYawInput(LookAxisVector.X);
		AddControllerPitchInput(LookAxisVector.Y);
	}
}
void ARewindPlayerCharacter::Attack()
{
	if (bIsDefending|| bIsStunned) return; // �h�䒆�͍U���֎~
	

	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (!AnimInstance || !AttackMontage) return;

	// �U�����Ă��Ȃ�
	if (!AnimInstance->Montage_IsPlaying(AttackMontage))
	{
		bWantsToCombo = false;
		bCanCheckCombo = false;
		bIsAttacking = true;
		ComboCount = 1;

		
		AnimInstance->Montage_Play(AttackMontage);

		FOnMontageBlendingOutStarted BlendOutDelegate;
		BlendOutDelegate.BindUObject(this, &ARewindPlayerCharacter::OnAttackMontageEnded);
		AnimInstance->Montage_SetBlendingOutDelegate(BlendOutDelegate, AttackMontage);
		AnimInstance->Montage_JumpToSection(FName("AttackA_Begin"), AttackMontage);
	}
	else if (bCanCheckCombo)
	{
		// �R���{����
		bWantsToCombo = true;
		
	}
}
void ARewindPlayerCharacter::PlayComboSection()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (!AnimInstance || !AttackMontage) return;

	FName CurrentSection = AnimInstance->Montage_GetCurrentSection();

	if (ComboCount==1||CurrentSection == "AttackA_Connect"||CurrentSection=="AttackA_Over")
	{
		AnimInstance->Montage_JumpToSection(FName("AttackB_Begin"), AttackMontage);
		ComboCount = 2;
	}
	else if (ComboCount == 2 || CurrentSection == "AttackB_Connect" || CurrentSection == "AttackB_Over")
	{
		AnimInstance->Montage_JumpToSection(FName("AttackC_Begin"), AttackMontage);
		ComboCount = 0;
	}
}
void ARewindPlayerCharacter::OnAttackMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage == AttackMontage)
	{
		bIsAttacking = false;
		bCanCheckCombo = false;
		bWantsToCombo = false;
		ComboCount = 0;
	}
	
}
void ARewindPlayerCharacter::CheckEnemiesByOverlap(float Radius, float HalfAngleDegrees, float MaxHeightDiff)
{
	TArray<AActor*> OverlappedActors;

	// �����Ώۂ̓G�N���X�i�K�v�ɉ����ĕύX�j
	TArray<TSubclassOf<AActor>> ActorFilter;
	ActorFilter.Add(ACharacter::StaticClass());

	const FVector Center = GetActorLocation();
	const FVector Forward = GetActorForwardVector();

	// ���̓��̃A�N�^�[���擾�i�����j
	UKismetSystemLibrary::SphereOverlapActors(
		GetWorld(),
		Center,
		Radius,
		TArray<TEnumAsByte<EObjectTypeQuery>>{ EObjectTypeQuery::ObjectTypeQuery3 }, // Pawn��
		ACharacter::StaticClass(), // �G�L�����̐e�N���X
		TArray<AActor*>(), // ���O�Ώ�
		OverlappedActors
	);

	for (AActor* Actor : OverlappedActors)
	{
		if (!Actor || Actor == this) continue;

		// ���፷�`�F�b�N
		if (FMath::Abs(Actor->GetActorLocation().Z - Center.Z) > MaxHeightDiff)
			continue;

		FVector ToTarget = Actor->GetActorLocation() - Center;
		ToTarget.Normalize();

		float Dot = FVector::DotProduct(Forward, ToTarget);
		float Angle = FMath::RadiansToDegrees(FMath::Acos(Dot));

		if (Angle <= HalfAngleDegrees)
		{
			UE_LOG(LogTemp, Warning, TEXT("����: %s"), *Actor->GetName());
			UGameplayStatics::ApplyDamage(Actor, 10.0f, GetController(), this, nullptr);
		}
	}

	// �I�[�o�[���b�v�͈͂��f�o�b�O�\��
	DrawDebugSphere(GetWorld(), Center, Radius, 16, FColor::Red, false, 1.0f);
}

void ARewindPlayerCharacter::StartDefend()
{
	if (bIsStunned|| bIsDefending || !DefendMontage) return;

	bIsDefending = true;
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (!AnimInstance) return;

	// �U�����Ȃ狭���I��
	if (bIsAttacking)
	{
		AnimInstance->Montage_Stop(0.2f, AttackMontage);
		bIsAttacking = false;
		bWantsToCombo = false;
		bCanCheckCombo = false;
		ComboCount = 0;
	}

	bIsDefending = true;

	AnimInstance->Montage_Play(DefendMontage);

}

void ARewindPlayerCharacter::EndDefend()
{
	if (bIsDefending)
	{
		bIsDefending = false;
		GetMesh()->GetAnimInstance()->Montage_Stop(0.2f, DefendMontage);
	}
}
void ARewindPlayerCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	// �L�����N�^�[�̈ړ����x���v�Z
	
	if (URewindAnimInstance* AnimInstance = Cast<URewindAnimInstance>(GetMesh()->GetAnimInstance()))
	{
		AnimInstance->Speed = GetVelocity().Size();
		AnimInstance->moveAnimeSpeed = GetVelocity().Size() / GetCharacterMovement()->MaxWalkSpeed;
	}
	
}
