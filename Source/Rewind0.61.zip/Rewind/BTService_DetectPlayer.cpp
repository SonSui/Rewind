// Fill out your copyright notice in the Description page of Project Settings.


#include "BTService_DetectPlayer.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"
#include "EnemyGruxCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"

UBTService_DetectPlayer::UBTService_DetectPlayer()
{
	NodeName = TEXT("Detect Player");
	Interval = 0.3f; // 0.3�b���ƂɃ`�F�b�N
}

void UBTService_DetectPlayer::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	AEnemyGruxCharacter* Grux = Cast<AEnemyGruxCharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (!Grux) return;

	UBlackboardComponent* BB = OwnerComp.GetBlackboardComponent();
	if (!BB) return;

	bool bVisible = Grux->IsPlayerVisible();
	BB->SetValueAsBool(TEXT("bPlayerDetected"), bVisible);

	if (bVisible)
	{
		APawn* Player = UGameplayStatics::GetPlayerPawn(Grux->GetWorld(), 0);
		BB->SetValueAsObject(TEXT("TargetActor"), Player);
	}
	else
	{
		BB->ClearValue(TEXT("TargetActor"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UBTService_DetectPlayer : %s"), bVisible ? TEXT("true") : TEXT("false"));
}