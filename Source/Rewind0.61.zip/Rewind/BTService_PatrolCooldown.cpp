// Fill out your copyright notice in the Description page of Project Settings.


#include "BTService_PatrolCooldown.h"
#include "EnemyGruxCharacter.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"

UBTService_PatrolCooldown::UBTService_PatrolCooldown()
{
    NodeName = TEXT("Patrol Cooldown Timer");
    Interval = 0.2f;
}

void UBTService_PatrolCooldown::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
    Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

    AEnemyGruxCharacter* Grux = Cast<AEnemyGruxCharacter>(OwnerComp.GetAIOwner()->GetPawn());
    if (!Grux) return;

    UBlackboardComponent* BB = OwnerComp.GetBlackboardComponent();
    if (!BB) return;

    if (Grux->bCanPatrol)
    {
        // ���łɃp�g���[���\�Ȃ�^�C�}�[�����Z�b�g
        PatrolTimers.FindOrAdd(Grux) = 0.0f;
        return;
    }

    // �^�C�}�[��~��
    float& Timer = PatrolTimers.FindOrAdd(Grux);
    Timer += DeltaSeconds;

    if (Timer >= Grux->PatrolInterval)
    {
        BB->SetValueAsBool(TEXT("bCanPatrol"), true);
        Grux->bCanPatrol = true;
        Timer = 0.0f;
    }
    UE_LOG(LogTemp, Warning, TEXT("Grux: UBTService_PatrolCooldown : %f"), Timer);
}
