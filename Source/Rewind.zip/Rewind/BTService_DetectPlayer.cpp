// Fill out your copyright notice in the Description page of Project Settings.


#include "BTService_DetectPlayer.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"
#include "EnemyGruxCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"

UBTService_DetectPlayer::UBTService_DetectPlayer()
{
	NodeName = TEXT("Detect Player");
	Interval = 0.5f; // ���b���ƂɃ`�F�b�N
}

void UBTService_DetectPlayer::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	AAIController* AICon = OwnerComp.GetAIOwner();
	if (!AICon) return;

	APawn* SelfPawn = AICon->GetPawn();
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!SelfPawn || !PlayerPawn) return;

	const FVector MyLoc = SelfPawn->GetActorLocation();
	const FVector TargetLoc = PlayerPawn->GetActorLocation();

	// �������`�F�b�N
	if (FMath::Abs(TargetLoc.Z - MyLoc.Z) > MaxZDifference)
	{
		OwnerComp.GetBlackboardComponent()->SetValueAsBool(TEXT("bCanSeePlayer"), false);
		return;
	}

	// �����`�F�b�N
	const float Distance = FVector::Dist2D(MyLoc, TargetLoc);
	if (Distance > SightRadius)
	{
		OwnerComp.GetBlackboardComponent()->SetValueAsBool(TEXT("bCanSeePlayer"), false);
		return;
	}

	// �p�x�`�F�b�N
	FVector ToTarget = TargetLoc - MyLoc;
	ToTarget.Z = 0;
	ToTarget.Normalize();
	FVector Forward = SelfPawn->GetActorForwardVector();
	const float Angle = FMath::RadiansToDegrees(FMath::Acos(FVector::DotProduct(Forward, ToTarget)));
	if (Angle > SightAngle)
	{
		OwnerComp.GetBlackboardComponent()->SetValueAsBool(TEXT("bCanSeePlayer"), false);
		return;
	}

	// �ː��Օ��`�F�b�N
	FHitResult HitResult;
	FCollisionQueryParams Query;
	Query.AddIgnoredActor(SelfPawn);
	Query.AddIgnoredActor(PlayerPawn);
	bool bHit = GetWorld()->LineTraceSingleByChannel(HitResult, MyLoc + FVector(0, 0, 50), TargetLoc + FVector(0, 0, 50), ECC_Visibility, Query);

	if (bHit && HitResult.GetActor() != PlayerPawn)
	{
		OwnerComp.GetBlackboardComponent()->SetValueAsBool(TEXT("bCanSeePlayer"), false);
		return;
	}

	// ���F����
	OwnerComp.GetBlackboardComponent()->SetValueAsBool(TEXT("bCanSeePlayer"), true);
	OwnerComp.GetBlackboardComponent()->SetValueAsObject(TEXT("TargetActor"), PlayerPawn);
}

