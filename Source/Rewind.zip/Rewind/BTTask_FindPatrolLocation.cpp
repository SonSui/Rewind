// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_FindPatrolLocation.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"
#include "EnemyGruxCharacter.h"

UBTTask_FindPatrolLocation::UBTTask_FindPatrolLocation()
{
	NodeName = TEXT("Find Patrol Location");
	// Blackboard Key������
	TargetLocationKey.SelectedKeyName = "TargetLocation";
}

EBTNodeResult::Type UBTTask_FindPatrolLocation::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AICon = OwnerComp.GetAIOwner();
	if (!AICon) return EBTNodeResult::Failed;

	AEnemyGruxCharacter* Grux = Cast<AEnemyGruxCharacter>(AICon->GetPawn());
	if (!Grux) return EBTNodeResult::Failed;

	// ���݈ʒu����Ƀ����_���ʒu�𐶐�
	FVector Origin = Grux->GetSpawnPoint();
	FVector RandDir = FMath::VRand().GetSafeNormal2D();
	FVector TargetPos = Origin + RandDir * PatrolRadius;

	// Blackboard�ɏ�������
	OwnerComp.GetBlackboardComponent()->SetValueAsVector(TargetLocationKey.SelectedKeyName, TargetPos);

	return EBTNodeResult::Succeeded;
}