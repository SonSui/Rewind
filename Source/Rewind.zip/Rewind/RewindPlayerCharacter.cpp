﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "RewindPlayerCharacter.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/PlayerController.h"
#include "RewindAnimInstance.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/CharacterMovementComponent.h"

ARewindPlayerCharacter::ARewindPlayerCharacter()
{
	GetMesh()->SetRelativeRotation(FRotator(0.0f, -90.0f, 0.0f));
	GetMesh()->SetRelativeLocation(FVector(0.0f, 0.0f, -90.0f));

	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	PrimaryActorTick.bCanEverTick = true;

	// カメラアームの作成
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = 300.0f; // カメラ距離
	CameraBoom->bUsePawnControlRotation = true; // カメラをコントローラーに追従

	// フォローカメラの作成
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	FollowCamera->bUsePawnControlRotation = false; // カメラは独自に回転しない

	PrimaryActorTick.bCanEverTick = true;

	CurrentHealth = MaxHealth; // 初期体力設定
	
}

void ARewindPlayerCharacter::BeginPlay()
{
	Super::BeginPlay();

	// 入力マッピングを登録
	if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
		{
			if (DefaultMappingContext)
			{
				Subsystem->AddMappingContext(DefaultMappingContext, 0);
			}
		}
	}
}

void ARewindPlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	if (UEnhancedInputComponent* EnhancedInput = CastChecked<UEnhancedInputComponent>(PlayerInputComponent))
	{
		if (MoveAction)
		{
			EnhancedInput->BindAction(MoveAction, ETriggerEvent::Triggered, this, &ARewindPlayerCharacter::Move);
		}
		if (LookAction)
		{
			EnhancedInput->BindAction(LookAction, ETriggerEvent::Triggered, this, &ARewindPlayerCharacter::Look);
		}
		if (AttackAction)
		{
			EnhancedInput->BindAction(AttackAction, ETriggerEvent::Started, this, &ARewindPlayerCharacter::Attack);
		}
		if (DefendAction)
		{
			EnhancedInput->BindAction(DefendAction, ETriggerEvent::Started, this, &ARewindPlayerCharacter::StartDefend);
			EnhancedInput->BindAction(DefendAction, ETriggerEvent::Completed, this, &ARewindPlayerCharacter::EndDefend);
		}
	}
}

void ARewindPlayerCharacter::Move(const FInputActionValue& Value)
{
	if (bIsAttacking||bIsDefending) return; // 攻撃中は移動禁止
	const FVector2D MovementVector = Value.Get<FVector2D>();
	CurrentInputVector = MovementVector;

	const FRotator ControlRotation = Controller ? Controller->GetControlRotation() : FRotator::ZeroRotator;
	const FRotator YawRotation(0, ControlRotation.Yaw, 0);

	// 世界方向へ変換
	const FVector ForwardDir = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
	const FVector RightDir = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);

	// 移動
	AddMovementInput(ForwardDir, MovementVector.Y);
	AddMovementInput(RightDir, MovementVector.X);

	// カメラにあわせて回転
	if (!MovementVector.IsNearlyZero())
	{
		const FVector WorldInput = ForwardDir * MovementVector.Y + RightDir * MovementVector.X;
		const FRotator TargetRotation = WorldInput.Rotation();
		
		const FRotator NewRotation = FMath::RInterpTo(GetActorRotation(), TargetRotation, GetWorld()->GetDeltaSeconds(), 10.0f);
		SetActorRotation(NewRotation);
	}

	const FVector InputDirectionWorld = ForwardDir * MovementVector.Y + RightDir * MovementVector.X;

	// キャラクターのローカル座標系に変換
	const FVector InputInLocal = GetActorTransform().InverseTransformVector(InputDirectionWorld);

	// アニメーション用InputVectorに設定
	if (URewindAnimInstance* AnimInstance = Cast<URewindAnimInstance>(GetMesh()->GetAnimInstance()))
	{
		AnimInstance->InputVector = FVector2D(InputInLocal.Y, InputInLocal.X);
		
	}
}

void ARewindPlayerCharacter::Look(const FInputActionValue& Value)
{
	const FVector2D LookAxisVector = Value.Get<FVector2D>();

	if (Controller)
	{
		AddControllerYawInput(LookAxisVector.X);
		AddControllerPitchInput(LookAxisVector.Y);
	}
}
void ARewindPlayerCharacter::Attack()
{
	if (bIsDefending|| bIsStunned) return; // 防御中は攻撃禁止
	

	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (!AnimInstance || !AttackMontage) return;

	// 攻撃していない
	if (!AnimInstance->Montage_IsPlaying(AttackMontage))
	{
		bWantsToCombo = false;
		bCanCheckCombo = false;
		bIsAttacking = true;
		ComboCount = 1;

		
		AnimInstance->Montage_Play(AttackMontage);

		FOnMontageBlendingOutStarted BlendOutDelegate;
		BlendOutDelegate.BindUObject(this, &ARewindPlayerCharacter::OnAttackMontageEnded);
		AnimInstance->Montage_SetBlendingOutDelegate(BlendOutDelegate, AttackMontage);
		AnimInstance->Montage_JumpToSection(FName("AttackA_Begin"), AttackMontage);
	}
	else if (bCanCheckCombo)
	{
		// コンボ判定
		bWantsToCombo = true;
		
	}
}
void ARewindPlayerCharacter::PlayComboSection()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (!AnimInstance || !AttackMontage) return;

	FName CurrentSection = AnimInstance->Montage_GetCurrentSection();

	if (ComboCount==1||CurrentSection == "AttackA_Connect"||CurrentSection=="AttackA_Over")
	{
		AnimInstance->Montage_JumpToSection(FName("AttackB_Begin"), AttackMontage);
		ComboCount = 2;
	}
	else if (ComboCount == 2 || CurrentSection == "AttackB_Connect" || CurrentSection == "AttackB_Over")
	{
		AnimInstance->Montage_JumpToSection(FName("AttackC_Begin"), AttackMontage);
		ComboCount = 0;
	}
}
void ARewindPlayerCharacter::OnAttackMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage == AttackMontage)
	{
		bIsAttacking = false;
		bCanCheckCombo = false;
		bWantsToCombo = false;
		ComboCount = 0;
	}
	
}
void ARewindPlayerCharacter::CheckEnemiesByOverlap(float Radius, float HalfAngleDegrees, float MaxHeightDiff)
{
	TArray<AActor*> OverlappedActors;

	// 検索対象の敵クラス（必要に応じて変更）
	TArray<TSubclassOf<AActor>> ActorFilter;
	ActorFilter.Add(ACharacter::StaticClass());

	const FVector Center = GetActorLocation();
	const FVector Forward = GetActorForwardVector();

	// 球体内のアクターを取得（高速）
	UKismetSystemLibrary::SphereOverlapActors(
		GetWorld(),
		Center,
		Radius,
		TArray<TEnumAsByte<EObjectTypeQuery>>{ EObjectTypeQuery::ObjectTypeQuery3 }, // Pawn等
		ACharacter::StaticClass(), // 敵キャラの親クラス
		TArray<AActor*>(), // 除外対象
		OverlappedActors
	);

	for (AActor* Actor : OverlappedActors)
	{
		if (!Actor || Actor == this) continue;

		// 高低差チェック
		if (FMath::Abs(Actor->GetActorLocation().Z - Center.Z) > MaxHeightDiff)
			continue;

		FVector ToTarget = Actor->GetActorLocation() - Center;
		ToTarget.Normalize();

		float Dot = FVector::DotProduct(Forward, ToTarget);
		float Angle = FMath::RadiansToDegrees(FMath::Acos(Dot));

		if (Angle <= HalfAngleDegrees)
		{
			UE_LOG(LogTemp, Warning, TEXT("命中: %s"), *Actor->GetName());
			UGameplayStatics::ApplyDamage(Actor, 10.0f, GetController(), this, nullptr);
		}
	}

	// オーバーラップ範囲をデバッグ表示
	DrawDebugSphere(GetWorld(), Center, Radius, 16, FColor::Red, false, 1.0f);
}

void ARewindPlayerCharacter::StartDefend()
{
	if (bIsStunned|| bIsDefending || !DefendMontage) return;

	bIsDefending = true;
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (!AnimInstance) return;

	// 攻撃中なら強制終了
	if (bIsAttacking)
	{
		AnimInstance->Montage_Stop(0.2f, AttackMontage);
		bIsAttacking = false;
		bWantsToCombo = false;
		bCanCheckCombo = false;
		ComboCount = 0;
	}

	bIsDefending = true;

	AnimInstance->Montage_Play(DefendMontage);

}

void ARewindPlayerCharacter::EndDefend()
{
	if (bIsDefending)
	{
		bIsDefending = false;
		GetMesh()->GetAnimInstance()->Montage_Stop(0.2f, DefendMontage);
	}
}
void ARewindPlayerCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	// キャラクターの移動速度を計算
	
	if (URewindAnimInstance* AnimInstance = Cast<URewindAnimInstance>(GetMesh()->GetAnimInstance()))
	{
		AnimInstance->Speed = GetVelocity().Size();
		AnimInstance->moveAnimeSpeed = GetVelocity().Size() / GetCharacterMovement()->MaxWalkSpeed;
	}
	
}
