// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_ChasePlayer.h"
#include "AIController.h"
#include "EnemyGruxCharacter.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "GameFramework/Character.h"
#include "NavigationSystem.h"

UBTTask_ChasePlayer::UBTTask_ChasePlayer()
{
	NodeName = TEXT("Chase Player");
	bNotifyTick = true;
}

EBTNodeResult::Type UBTTask_ChasePlayer::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AICon = OwnerComp.GetAIOwner();
	if (!AICon) return EBTNodeResult::Failed;

	AEnemyGruxCharacter* Grux = Cast<AEnemyGruxCharacter>(AICon->GetPawn());
	if (!Grux) return EBTNodeResult::Failed;

	UObject* TargetObj = OwnerComp.GetBlackboardComponent()->GetValueAsObject("TargetActor");
	APawn* Target = Cast<APawn>(TargetObj);
	if (!Target) return EBTNodeResult::Failed;

	TargetLocation = Target->GetActorLocation();
	AICon->MoveToLocation(TargetLocation, AcceptanceRadius);

	return EBTNodeResult::InProgress;
}

void UBTTask_ChasePlayer::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	AAIController* AICon = OwnerComp.GetAIOwner();
	if (!AICon) return;

	APawn* ControlledPawn = AICon->GetPawn();
	if (!ControlledPawn) return;

	float Distance = FVector::DistXY(ControlledPawn->GetActorLocation(), TargetLocation);

	// �͈͓�
	if (Distance <= AcceptanceRadius)
	{
		AICon->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
	}
}