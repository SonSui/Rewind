// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyGruxCharacter.h"
#include "AIController.h"
#include "Kismet/GameplayStatics.h"

AEnemyGruxCharacter::AEnemyGruxCharacter()
{
	PrimaryActorTick.bCanEverTick = true; // �s���X�V�̂��߂�Tick��ON
	
}

void AEnemyGruxCharacter::BeginPlay()
{
	Super::BeginPlay();
	SpawnPoint = GetActorLocation();

	// �ŏ��̃p�g���[�����J�n
	GetWorldTimerManager().SetTimer(PatrolTimerHandle, this, &AEnemyGruxCharacter::Patrol, 2.0f, true);
	HitCountInAttack2 = 0;
}

void AEnemyGruxCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!bIsDead && !bIsStunned)
	{
		if (DetectPlayer())
		{
			bInCombat = true;
			// �U���܂��͐ڋ�
			if (!bIsAttacking)
			{
				PerformAttack();
			}
		}
		else
		{
			bInCombat = false;
		}
	}
}

bool AEnemyGruxCharacter::DetectPlayer()
{
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!PlayerPawn) return false;

	const FVector MyLocation = GetActorLocation();
	const FVector Forward = GetActorForwardVector();
	const FVector TargetLocation = PlayerPawn->GetActorLocation();

	DrawDebugLine(GetWorld(), MyLocation + FVector(0, 0, 50), TargetLocation + FVector(0, 0, 50), FColor::Red, false, 0.1f, 0, 2.0f);

	// ���፷�`�F�b�N
	if (FMath::Abs(TargetLocation.Z - MyLocation.Z) > 100.0f)
		return false;

	// �����`�F�b�N
	const float Distance = FVector::Dist2D(MyLocation, TargetLocation);
	if (Distance > SightRadius) return false;

	// �p�x�`�F�b�N
	FVector ToPlayer = TargetLocation - MyLocation;
	ToPlayer.Z = 0;
	ToPlayer.Normalize();
	const float Angle = FMath::RadiansToDegrees(FMath::Acos(FVector::DotProduct(Forward, ToPlayer)));
	if (Angle > SightAngle) return false;

	// �ː��Օ��`�F�b�N
	FHitResult HitResult;
	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(this); // ����
	QueryParams.AddIgnoredActor(PlayerPawn); // ����

	const bool bHit = GetWorld()->LineTraceSingleByChannel(
		HitResult,
		MyLocation + FVector(0, 0, 50),
		TargetLocation + FVector(0, 0, 50),
		ECollisionChannel::ECC_Visibility,
		QueryParams
	);

	if (bHit && HitResult.GetActor() != PlayerPawn)
		return false;

	return true;
}

void AEnemyGruxCharacter::Patrol()
{
	if (bInCombat || bIsDead || bIsStunned) return;

	// ����ڕW�_��ݒ�
	const FVector RandDir = FMath::VRand().GetSafeNormal2D();
	const FVector Target = SpawnPoint + RandDir * PatrolRadius;
	MoveToLocation(Target);
}

void AEnemyGruxCharacter::MoveToLocation(const FVector& Location)
{
	AAIController* AI = Cast<AAIController>(GetController());
	if (AI)
	{
		AI->MoveToLocation(Location);
	}
}

void AEnemyGruxCharacter::PerformAttack()
{
	if (bIsAttacking || bIsDead) return;

	bIsAttacking = true;
	

	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (!Anim || !AttackMontage || !AttackPreMontage) return;

	// �U���O�����^�[�W�����Đ�
	Anim->Montage_Play(AttackPreMontage);

	// �I����ɍU�����[�V�������Đ�����f���Q�[�g��o�^
	FOnMontageEnded MontageEndDelegate;
	MontageEndDelegate.BindLambda([this](UAnimMontage* Montage, bool bInterrupted)
		{
			if (!bInterrupted && AttackMontage)
			{
				UAnimInstance* AnimInst = GetMesh()->GetAnimInstance();
				if (AnimInst)
				{
					AnimInst->Montage_Play(AttackMontage);

					// �U���I���^�C�}�[�J�n
					GetWorldTimerManager().SetTimer(AttackCooldownTimer, this, &AEnemyGruxCharacter::ResetAttack, AttackCooldown, false);
				}
			}
			else
			{
				// ���f���ꂽ�ꍇ�ł����Z�b�g����
				ResetAttack();
			}
		});

	Anim->Montage_SetEndDelegate(MontageEndDelegate, AttackPreMontage);
}
float AEnemyGruxCharacter::TakeDamage(float DamageAmount, FDamageEvent const& DamageEvent, AController* DmgInstigator, AActor* Causer)
{
	const float Applied = Super::TakeDamage(DamageAmount, DamageEvent, DmgInstigator, Causer);

	if (bIsAttacking && AttackMontage2) // �U��2��
	{
		HitCountInAttack2++;
		if (HitCountInAttack2 >= MaxHitsBeforeStun)
		{
			// �X�^���i���݁j����
			bIsStunned = true;
			bIsAttacking = false;
			PlayHitMontage(); // �X�^�����ɑ��̍s���𒆒f
			HitCountInAttack2 = 0;
			
		}
	}

	return Applied;
}

