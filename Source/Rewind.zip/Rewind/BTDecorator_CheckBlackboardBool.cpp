// Fill out your copyright notice in the Description page of Project Settings.


#include "BTDecorator_CheckBlackboardBool.h"
#include "BehaviorTree/BlackboardComponent.h"

UBTDecorator_CheckBlackboardBool::UBTDecorator_CheckBlackboardBool()
{
	NodeName = TEXT("Check Blackboard Bool == True");
}

bool UBTDecorator_CheckBlackboardBool::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	// Blackboard����Bool�l���擾
	const bool bValue = OwnerComp.GetBlackboardComponent()->GetValueAsBool(BoolKey.SelectedKeyName);
	return bValue;
}