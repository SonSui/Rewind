// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "RewindEnemyBaseCharacter.h"
#include "EnemyGruxCharacter.generated.h"

/**
 * 
 */
UCLASS()
class REWIND_API AEnemyGruxCharacter : public ARewindEnemyBaseCharacter
{
	GENERATED_BODY()
public:
	AEnemyGruxCharacter();
protected:
	virtual void BeginPlay() override;

	// �ړ����x
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Stats")
	float MoveSpeed = 300.0f;

	// �v���C���[���m�͈́i��`�j
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Sight")
	float SightRadius = 800.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Sight")
	float SightAngle = 60.0f;

	// �U��1�E�U��2
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Animation")
	UAnimMontage* AttackPreMontage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Animation")
	UAnimMontage* AttackMontage2;

	// �U�����ɔ�e������
	int32 HitCountInAttack2 = 0;

	// �U��2���Ɂ���ȏ�팂�ŋ���
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Combat")
	int32 MaxHitsBeforeStun = 3;

	// �p�g���[���p
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grux|Patrol")
	float PatrolRadius = 600.0f;

	FVector SpawnPoint;
	FTimerHandle PatrolTimerHandle;

	// AI����
	void Patrol();
	void MoveToLocation(const FVector& Location);

	// ���͈͓��Ƀv���C���[�����邩
	bool DetectPlayer();

	// ��ԊǗ�
	bool bInCombat = false;
	bool bIsStunned = false;


	virtual void Tick(float DeltaSeconds) override;
	
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;

public:
	bool IsAttacking() const { return bIsAttacking; }
	virtual void PerformAttack() override;

	FVector GetSpawnPoint() const { return FVector(SpawnPoint); }

};
