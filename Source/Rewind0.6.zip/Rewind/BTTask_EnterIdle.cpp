// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_EnterIdle.h"
#include "EnemyGruxCharacter.h"
#include "AIController.h"

UBTTask_EnterIdle::UBTTask_EnterIdle()
{
	NodeName = TEXT("Enter Idle");
}

EBTNodeResult::Type UBTTask_EnterIdle::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AEnemyGruxCharacter* Grux = Cast<AEnemyGruxCharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (!Grux) return EBTNodeResult::Failed;

	return Grux->EnterIdle() ? EBTNodeResult::Succeeded : EBTNodeResult::Failed;
}
